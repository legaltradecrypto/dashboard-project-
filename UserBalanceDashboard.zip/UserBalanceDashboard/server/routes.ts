import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, updateFinancialSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // User authentication routes
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Return user data without password
      const { password: _, ...userData } = user;
      return res.status(200).json(userData);
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const newUser = await storage.createUser(validatedData);
      
      // Return user data without password
      const { password: _, ...userData } = newUser;
      return res.status(201).json(userData);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Registration error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Financial data routes
  app.get("/api/user/:username/financial", async (req: Request, res: Response) => {
    try {
      const { username } = req.params;
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return financial data with currency
      const financialData = {
        balance: user.balance,
        bonus: user.bonus,
        completedWithdrawal: user.completedWithdrawal,
        currency: user.currency,
        balanceUpdated: user.balanceUpdated,
        bonusUpdated: user.bonusUpdated,
        withdrawalUpdated: user.withdrawalUpdated
      };
      
      return res.status(200).json(financialData);
    } catch (error) {
      console.error("Get financial data error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/user/:username/financial", async (req: Request, res: Response) => {
    try {
      const { username } = req.params;
      const validatedData = updateFinancialSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUserFinancial(username, validatedData);
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update user financial data" });
      }
      
      // Return updated financial data
      const financialData = {
        balance: updatedUser.balance,
        bonus: updatedUser.bonus,
        completedWithdrawal: updatedUser.completedWithdrawal,
        currency: updatedUser.currency,
        balanceUpdated: updatedUser.balanceUpdated,
        bonusUpdated: updatedUser.bonusUpdated,
        withdrawalUpdated: updatedUser.withdrawalUpdated
      };
      
      return res.status(200).json(financialData);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Update financial data error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
