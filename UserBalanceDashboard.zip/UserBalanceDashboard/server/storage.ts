import {
  users,
  type User,
  type InsertUser,
  type UpdateFinancial
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserFinancial(username: string, data: UpdateFinancial): Promise<User | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.currentId = 1;
    
    // Add a default admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      email: "admin@example.com",
      fullName: "Admin User",
      phoneNumber: "1234567890",
      currency: "USD"
    }).then(user => {
      const adminUser = { ...user, isAdmin: true };
      this.users.set(user.id, adminUser);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id,
      currency: insertUser.currency || "USD",
      balance: "0.00",
      bonus: "0.00",
      completedWithdrawal: "0.00",
      isAdmin: false,
      balanceUpdated: "Never",
      bonusUpdated: "Never",
      withdrawalUpdated: "Never"
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserFinancial(username: string, data: UpdateFinancial): Promise<User | undefined> {
    const user = await this.getUserByUsername(username);
    if (!user) return undefined;

    const updatedUser: User = {
      ...user,
      balance: data.balance,
      bonus: data.bonus,
      completedWithdrawal: data.completedWithdrawal,
      balanceUpdated: "Just now",
      bonusUpdated: "Just now",
      withdrawalUpdated: "Just now"
    };

    this.users.set(user.id, updatedUser);
    return updatedUser;
  }
}

export const storage = new MemStorage();
