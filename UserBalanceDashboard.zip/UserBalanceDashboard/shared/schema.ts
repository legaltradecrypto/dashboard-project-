import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  fullName: text("full_name").notNull(),
  phoneNumber: text("phone_number").notNull(),
  currency: text("currency").notNull().default("USD"),
  balance: text("balance").notNull().default("0.00"),
  bonus: text("bonus").notNull().default("0.00"),
  completedWithdrawal: text("completed_withdrawal").notNull().default("0.00"),
  isAdmin: boolean("is_admin").notNull().default(false),
  balanceUpdated: text("balance_updated").notNull().default("Never"),
  bonusUpdated: text("bonus_updated").notNull().default("Never"),
  withdrawalUpdated: text("withdrawal_updated").notNull().default("Never"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  phoneNumber: true,
  currency: true,
});

export const updateFinancialSchema = z.object({
  balance: z.string().regex(/^\d+(\.\d{1,2})?$/),
  bonus: z.string().regex(/^\d+(\.\d{1,2})?$/),
  completedWithdrawal: z.string().regex(/^\d+(\.\d{1,2})?$/),
});

export const currencySymbols: Record<string, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  JPY: "¥",
  CNY: "¥",
  INR: "₹",
  AUD: "A$",
  CAD: "C$",
  CHF: "CHF",
  ZAR: "R"
};

export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpdateFinancial = z.infer<typeof updateFinancialSchema>;
export type User = typeof users.$inferSelect;

// For client-side storage
export type UserData = {
  username: string;
  email: string;
  fullName: string;
  phoneNumber: string;
  currency: string;
  balance: string;
  bonus: string;
  completedWithdrawal: string;
  isAdmin: boolean;
  balanceUpdated: string;
  bonusUpdated: string;
  withdrawalUpdated: string;
};
