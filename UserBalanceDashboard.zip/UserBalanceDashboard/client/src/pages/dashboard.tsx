import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import UserDashboard from "@/components/UserDashboard";
import AdminDashboard from "@/components/AdminDashboard";
import Toast from "@/components/Toast";
import { getUserData } from "@/lib/localStorage";
import { UserData } from "@shared/schema";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const [userData, setUserData] = useState<UserData | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("Changes saved successfully!");

  useEffect(() => {
    const username = localStorage.getItem("username");
    if (!username) {
      navigate("/login");
      return;
    }

    const data = getUserData();
    if (data) {
      setUserData(data);
      setIsAdmin(data.isAdmin);
    }
  }, [navigate]);

  const handleToggleAdminMode = () => {
    setIsAdminMode(!isAdminMode);
  };

  const handleLogout = () => {
    localStorage.removeItem("username");
    navigate("/login");
  };

  const showToastNotification = (message: string) => {
    setToastMessage(message);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, 3000);
  };

  if (!userData) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header 
        username={userData.username} 
        isAdmin={isAdmin}
        isAdminMode={isAdminMode}
        onToggleAdminMode={handleToggleAdminMode}
        onLogout={handleLogout}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow">
        {isAdminMode && isAdmin ? (
          <AdminDashboard 
            userData={userData}
            onUpdateSuccess={(updatedData) => {
              setUserData(updatedData);
              showToastNotification("Changes saved successfully!");
            }}
          />
        ) : (
          <UserDashboard userData={userData} />
        )}
      </main>
      
      <Footer />
      
      <Toast 
        message={toastMessage}
        show={showToast}
      />
    </div>
  );
}
