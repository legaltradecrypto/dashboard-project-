import { UserData, currencySymbols } from "@shared/schema";
import FinancialCard from "./FinancialCard";

interface UserDashboardProps {
  userData: UserData;
}

export default function UserDashboard({ userData }: UserDashboardProps) {
  const formatCurrency = (value: string) => {
    const numValue = parseFloat(value);
    return new Intl.NumberFormat("en-US").format(numValue);
  };
  
  const currencySymbol = currencySymbols[userData.currency] || "$";
  
  // Sample recent activity items for display purposes
  const recentActivity = [
    {
      id: 1,
      type: "bonus",
      title: "Bonus Received",
      date: "Jul 12, 2023",
      amount: "+$50.00",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
        </svg>
      ),
    },
    {
      id: 2,
      type: "withdrawal",
      title: "Withdrawal Completed",
      date: "Jul 10, 2023",
      amount: "$200.00",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
      ),
    },
    {
      id: 3,
      type: "deposit",
      title: "Deposit",
      date: "Jul 5, 2023",
      amount: "+$500.00",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
        </svg>
      ),
    },
  ];

  return (
    <div id="user-dashboard">
      <div className="mb-6">
        <h2 className="text-xl font-medium text-gray-700">Account Summary</h2>
        <p className="text-gray-500 text-sm">View your current financial status</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <FinancialCard
          title="Balance"
          value={formatCurrency(userData.balance)}
          updatedAt={userData.balanceUpdated}
          badgeText="Available"
          badgeColor="blue"
          currencySymbol={currencySymbol}
        />
        
        <FinancialCard
          title="Bonus"
          value={formatCurrency(userData.bonus)}
          updatedAt={userData.bonusUpdated}
          badgeText="Earned"
          badgeColor="green"
          currencySymbol={currencySymbol}
        />
        
        <FinancialCard
          title="Completed Withdrawals"
          value={formatCurrency(userData.completedWithdrawal)}
          updatedAt={userData.withdrawalUpdated}
          badgeText="Processed"
          badgeColor="purple"
          currencySymbol={currencySymbol}
        />
      </div>

      <div className="mt-8 bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-700 mb-4">Recent Activity</h3>
        <div className="space-y-3">
          {recentActivity.map((activity) => (
            <div key={activity.id} className="flex items-center justify-between py-2 border-b border-gray-100">
              <div className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                  activity.type === "bonus" || activity.type === "deposit"
                    ? "bg-blue-100 text-blue-500"
                    : "bg-purple-100 text-purple-500"
                }`}>
                  {activity.icon}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">{activity.title}</p>
                  <p className="text-xs text-gray-500">{activity.date}</p>
                </div>
              </div>
              <span className={`text-sm font-medium ${
                activity.amount.startsWith("+") ? "text-green-600" : "text-purple-600"
              }`}>
                {activity.amount}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
