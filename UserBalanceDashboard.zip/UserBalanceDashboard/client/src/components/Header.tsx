import { Button } from "@/components/ui/button";

interface HeaderProps {
  username: string;
  isAdmin: boolean;
  isAdminMode: boolean;
  onToggleAdminMode: () => void;
  onLogout: () => void;
}

export default function Header({
  username,
  isAdmin,
  isAdminMode,
  onToggleAdminMode,
  onLogout,
}: HeaderProps) {
  return (
    <header className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
        <div className="flex items-center space-x-4">
          <span className="text-gray-600">Welcome, <span id="username">{username}</span></span>
          <Button
            variant="outline"
            size="sm"
            onClick={onLogout}
            className="text-sm bg-gray-200 hover:bg-gray-300 px-3 py-1 rounded transition"
          >
            Logout
          </Button>
          {isAdmin && (
            <Button
              size="sm"
              onClick={onToggleAdminMode}
              className={`text-sm ${
                isAdminMode
                  ? "bg-green-500 hover:bg-green-600"
                  : "bg-blue-600 hover:bg-blue-700"
              } text-white px-3 py-1 rounded transition`}
            >
              {isAdminMode ? "User Mode" : "Admin Mode"}
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
