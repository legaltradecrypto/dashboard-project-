interface FinancialCardProps {
  title: string;
  value: string;
  updatedAt: string;
  badgeText: string;
  badgeColor: "blue" | "green" | "purple";
  currencySymbol?: string;
}

export default function FinancialCard({
  title,
  value,
  updatedAt,
  badgeText,
  badgeColor,
  currencySymbol = "$",
}: FinancialCardProps) {
  const getBadgeClasses = () => {
    switch (badgeColor) {
      case "blue":
        return "bg-blue-100 text-blue-800";
      case "green":
        return "bg-green-100 text-green-800";
      case "purple":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="p-5">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-medium text-gray-700">{title}</h3>
          <span className={`text-xs px-2 py-1 ${getBadgeClasses()} rounded-full`}>
            {badgeText}
          </span>
        </div>
        <p className="text-3xl font-bold text-gray-800 mb-1">{currencySymbol}{value}</p>
        <p className="text-sm text-gray-500">Last updated: {updatedAt}</p>
      </div>
    </div>
  );
}
