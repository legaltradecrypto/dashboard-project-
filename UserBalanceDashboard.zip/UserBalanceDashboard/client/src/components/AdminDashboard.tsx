import { useState, FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { updateUserData } from "@/lib/localStorage";
import { UserData, updateFinancialSchema, currencySymbols } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

interface AdminDashboardProps {
  userData: UserData;
  onUpdateSuccess: (updatedData: UserData) => void;
}

export default function AdminDashboard({ userData, onUpdateSuccess }: AdminDashboardProps) {
  const [balance, setBalance] = useState(userData.balance);
  const [bonus, setBonus] = useState(userData.bonus);
  const [withdrawal, setWithdrawal] = useState(userData.completedWithdrawal);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const currencySymbol = currencySymbols[userData.currency] || "$";

  const formatCurrency = (value: string) => {
    const numValue = parseFloat(value);
    return new Intl.NumberFormat("en-US").format(numValue);
  };

  const validateInput = (data: any) => {
    try {
      updateFinancialSchema.parse(data);
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors = error.flatten().fieldErrors;
        const errorMessage = Object.entries(fieldErrors)
          .map(([field, errors]) => `${field}: ${errors?.join(", ")}`)
          .join("\n");
          
        toast({
          title: "Validation Error",
          description: errorMessage,
          variant: "destructive",
        });
      }
      return false;
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    const formData = {
      balance,
      bonus,
      completedWithdrawal: withdrawal,
    };
    
    if (!validateInput(formData)) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const response = await apiRequest(
        "PATCH",
        `/api/user/${userData.username}/financial`,
        formData
      );
      
      const updatedFinancialData = await response.json();
      
      // Update localStorage with the new values - create a clean object to avoid circular references
      const updatedUserData: UserData = {
        username: userData.username,
        email: userData.email,
        fullName: userData.fullName,
        phoneNumber: userData.phoneNumber,
        currency: userData.currency,
        balance: updatedFinancialData.balance || userData.balance,
        bonus: updatedFinancialData.bonus || userData.bonus,
        completedWithdrawal: updatedFinancialData.completedWithdrawal || userData.completedWithdrawal,
        isAdmin: userData.isAdmin,
        balanceUpdated: updatedFinancialData.balanceUpdated || "Just now",
        bonusUpdated: updatedFinancialData.bonusUpdated || "Just now",
        withdrawalUpdated: updatedFinancialData.withdrawalUpdated || "Just now",
      };
      
      updateUserData(updatedUserData);
      onUpdateSuccess(updatedUserData);
    } catch (error) {
      console.error("Failed to update financial data:", error);
      toast({
        title: "Update Failed",
        description: "Could not update the financial data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id="admin-dashboard">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-medium text-gray-700">Admin Dashboard</h2>
          <p className="text-gray-500 text-sm">Edit user financial information</p>
        </div>
        <Button
          onClick={handleSubmit}
          disabled={isSubmitting}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
        >
          {isSubmitting ? "Saving..." : "Save All Changes"}
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
        <div className="p-6">
          <h3 className="text-lg font-medium text-gray-700 mb-4">Edit User Information</h3>
          <form id="admin-form" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="edit-balance" className="block text-sm font-medium text-gray-700">Balance</Label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">{currencySymbol}</span>
                  <Input
                    type="text"
                    id="edit-balance"
                    name="balance"
                    value={balance}
                    onChange={(e) => setBalance(e.target.value)}
                    className="block w-full pl-8 pr-12 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <p className="text-xs text-gray-500">Current value: {currencySymbol}{formatCurrency(userData.balance)}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-bonus" className="block text-sm font-medium text-gray-700">Bonus</Label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">{currencySymbol}</span>
                  <Input
                    type="text"
                    id="edit-bonus"
                    name="bonus"
                    value={bonus}
                    onChange={(e) => setBonus(e.target.value)}
                    className="block w-full pl-8 pr-12 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <p className="text-xs text-gray-500">Current value: {currencySymbol}{formatCurrency(userData.bonus)}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-withdrawal" className="block text-sm font-medium text-gray-700">Completed Withdrawals</Label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">{currencySymbol}</span>
                  <Input
                    type="text"
                    id="edit-withdrawal"
                    name="withdrawal"
                    value={withdrawal}
                    onChange={(e) => setWithdrawal(e.target.value)}
                    className="block w-full pl-8 pr-12 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <p className="text-xs text-gray-500">Current value: {currencySymbol}{formatCurrency(userData.completedWithdrawal)}</p>
              </div>
            </div>
          </form>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="p-6">
          <h3 className="text-lg font-medium text-gray-700 mb-4">User Management</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Balance</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bonus</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Withdrawals</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500">
                        <span className="text-sm font-medium">
                          {userData.username.substring(0, 2).toUpperCase()}
                        </span>
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{userData.username}</div>
                        <div className="text-sm text-gray-500">Current User</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{currencySymbol}{userData.balance}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{currencySymbol}{userData.bonus}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{currencySymbol}{userData.completedWithdrawal}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className="text-indigo-600 hover:text-indigo-900 mr-2">
                      Currently Editing
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
