export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 py-4">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-sm text-gray-500 text-center">
          &copy; {new Date().getFullYear()} Dashboard System. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
