interface ToastProps {
  message: string;
  show: boolean;
}

export default function Toast({ message, show }: ToastProps) {
  return (
    <div
      id="toast"
      className={`fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded shadow-lg transform transition-transform duration-300 ${
        show ? "translate-y-0" : "translate-y-24"
      }`}
    >
      {message}
    </div>
  );
}
