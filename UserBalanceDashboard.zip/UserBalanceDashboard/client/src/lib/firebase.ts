import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, updateDoc, doc, getDoc, getDocs, query, where, Firestore } from "firebase/firestore";
import { User, InsertUser, UpdateFinancial } from "@shared/schema";

// Firebase configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  // Add any other Firebase configurations as needed
};

// Initialize Firebase
let app: any;
let db: Firestore | null = null;

try {
  app = initializeApp(firebaseConfig);
  db = getFirestore(app);
} catch (error) {
  console.error("Firebase initialization error:", error);
}

// Firestore Collections
const USERS_COLLECTION = "users";

// Helper Functions
export async function saveUserToFirestore(user: Omit<User, "password">) {
  if (!db) return null;
  
  try {
    // Remove sensitive information and any circular references before saving to Firestore
    const { password, ...userWithoutPassword } = user as any;
    
    // Create a clean object with only the data we want to store
    const cleanUserData = {
      username: userWithoutPassword.username,
      email: userWithoutPassword.email || "",
      fullName: userWithoutPassword.fullName || "",
      phoneNumber: userWithoutPassword.phoneNumber || "",
      currency: userWithoutPassword.currency || "USD",
      balance: userWithoutPassword.balance || "0.00",
      bonus: userWithoutPassword.bonus || "0.00",
      completedWithdrawal: userWithoutPassword.completedWithdrawal || "0.00",
      isAdmin: userWithoutPassword.isAdmin || false,
      balanceUpdated: userWithoutPassword.balanceUpdated || "Never",
      bonusUpdated: userWithoutPassword.bonusUpdated || "Never",
      withdrawalUpdated: userWithoutPassword.withdrawalUpdated || "Never",
      createdAt: new Date(),
    };
    
    // Add user to Firestore
    const docRef = await addDoc(collection(db, USERS_COLLECTION), cleanUserData);
    
    return docRef.id;
  } catch (error) {
    console.error("Error saving user to Firestore:", error);
    return null;
  }
}

export async function updateUserFinancialInFirestore(username: string, data: UpdateFinancial) {
  if (!db) return false;
  
  try {
    // Find the user document by username
    const usersRef = collection(db, USERS_COLLECTION);
    const q = query(usersRef, where("username", "==", username));
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) return false;
    
    // Create a clean update object to avoid circular references
    const updateData = {
      balance: data.balance,
      bonus: data.bonus,
      completedWithdrawal: data.completedWithdrawal,
      balanceUpdated: "Just now",
      bonusUpdated: "Just now",
      withdrawalUpdated: "Just now",
      updatedAt: new Date(),
    };
    
    // Update the first matching document
    const userDoc = querySnapshot.docs[0];
    await updateDoc(doc(db, USERS_COLLECTION, userDoc.id), updateData);
    
    return true;
  } catch (error) {
    console.error("Error updating user in Firestore:", error);
    return false;
  }
}

export async function getUserByUsernameFromFirestore(username: string) {
  if (!db) return null;
  
  try {
    const usersRef = collection(db, USERS_COLLECTION);
    const q = query(usersRef, where("username", "==", username));
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) return null;
    
    // Return the first matching document
    return { id: querySnapshot.docs[0].id, ...querySnapshot.docs[0].data() };
  } catch (error) {
    console.error("Error getting user from Firestore:", error);
    return null;
  }
}

export { db };