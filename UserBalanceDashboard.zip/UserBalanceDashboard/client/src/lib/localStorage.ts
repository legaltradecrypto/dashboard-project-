import { UserData } from "@shared/schema";

// Initialize user data in localStorage
export function initializeUserData(userData: any): UserData {
  const initialData: UserData = {
    username: userData.username,
    email: userData.email || "",
    fullName: userData.fullName || "",
    phoneNumber: userData.phoneNumber || "",
    currency: userData.currency || "USD",
    balance: userData.balance || "0.00",
    bonus: userData.bonus || "0.00",
    completedWithdrawal: userData.completedWithdrawal || "0.00",
    isAdmin: userData.isAdmin || false,
    balanceUpdated: userData.balanceUpdated || "Never",
    bonusUpdated: userData.bonusUpdated || "Never",
    withdrawalUpdated: userData.withdrawalUpdated || "Never",
  };
  
  localStorage.setItem("userData", JSON.stringify(initialData));
  return initialData;
}

// Get user data from localStorage
export function getUserData(): UserData | null {
  const storedData = localStorage.getItem("userData");
  
  if (!storedData) {
    const username = localStorage.getItem("username");
    
    if (!username) {
      return null;
    }
    
    return initializeUserData({ username });
  }
  
  return JSON.parse(storedData) as UserData;
}

// Update user data in localStorage
export function updateUserData(userData: UserData): void {
  localStorage.setItem("userData", JSON.stringify(userData));
}

// Make the current user an admin
export function makeUserAdmin(): void {
  const userData = getUserData();
  
  if (userData) {
    const updatedData = {
      ...userData,
      isAdmin: true,
    };
    
    updateUserData(updatedData);
  }
}

// Clear all user data from localStorage
export function clearUserData(): void {
  localStorage.removeItem("userData");
  localStorage.removeItem("username");
}
